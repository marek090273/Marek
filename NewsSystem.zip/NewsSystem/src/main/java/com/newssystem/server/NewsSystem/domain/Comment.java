package com.newssystem.server.NewsSystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The class is a reflection of the table in the mongoDB database
 */

@Document
public class Comment {

    /**
     * Using annotation @Id with id we will have Id generated automaticaly
     */
    @Id
    public String id;

    /**
     * NotNull annotations validate the entered data
     */
    @NotNull(message = "newsID can not be null")
    public String newsId;

    /**
     * NotNull and Size annotations validate the entered data
     */
    @NotNull(message = "Comment can not be null")
    @Size(min=5, max=2000, message = "min 5, max 2000 characters")
    public String comment;

    /**
     * NotNull and Size annotations validate the entered data
     */
    @NotNull(message = "Author can not be null")
    @Size(min=2, max=20, message = "min 2, max 20 characters")
    public String author;

    public String data;

    /**
     * Constructor
     */
    public Comment() {
    }

    /**
     * Constructor
     * @param newsId
     * @param comment
     * @param author
     * @param data
     */
    public Comment(String newsId, String comment, String author, String data) {
        this.newsId = newsId;
        this.comment = comment;
        this.author = author;
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNewsId() {
        return newsId;
    }

    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
