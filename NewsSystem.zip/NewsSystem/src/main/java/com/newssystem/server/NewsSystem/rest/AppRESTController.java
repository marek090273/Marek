package com.newssystem.server.NewsSystem.rest;

import com.newssystem.server.NewsSystem.domain.Comment;
import com.newssystem.server.NewsSystem.domain.News;
import com.newssystem.server.NewsSystem.service.CommentService;
import com.newssystem.server.NewsSystem.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * The controller allows displaying information in JSON form
 * depending on what address you choose and adding information to the database
 */

@RestController
@RequestMapping("/api/news")
public class AppRESTController {

    private final CommentService commentService;
    private final NewsService newsService;

    @Autowired
    public AppRESTController(CommentService commentService, NewsService newsService) {
        this.commentService = commentService;
        this.newsService = newsService;
    }

    /**
     * Returns a list of all news
     * @return - returns news from database
     */
    @RequestMapping(method = RequestMethod.GET, value = "/getNews")
    public @ResponseBody List<News> findAll() {

        return newsService.getObj();
    }

    /**
     * Returns a list of all comments
     * @return - returns comments from database
     */
    @RequestMapping(method = RequestMethod.GET, value = "/getComments")
    public @ResponseBody List<Comment> findAllComment() {

        return commentService.getObj();
    }

    /**
     * Allows you to add news to the database
     * @param newsEntity - object that has to be add to the database
     * @return - saved object
     */
    @RequestMapping(method = RequestMethod.POST, value = "/saveNews")
    public @ResponseBody News create(@RequestBody News newsEntity) {

        return newsService.create(newsEntity);
    }

    /**
     * Allows you to add comment to the database
     * @param commentEntity - object that has to be add to the database
     * @return - saved object
     */
    @RequestMapping(method = RequestMethod.POST, value = "/saveComment")
    public @ResponseBody
    Comment create(@RequestBody Comment commentEntity) {

        return commentService.create(commentEntity);
    }


}
