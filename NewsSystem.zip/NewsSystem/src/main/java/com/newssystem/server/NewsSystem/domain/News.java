package com.newssystem.server.NewsSystem.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


/**
 * The class is a reflection of the table in the mongoDB database
 */

@Document
public class News {

    /**
     * Using annotation @Id with id we will have Id generated automaticaly
     */
    @Id
    public String id;


    /**
     * NotNull and Size annotations validate the entered data
     */
    @NotNull(message = "Title can not be null")
    @Size(min=5, max =70, message="min 5 characters, max 70 characters")
    public String title;

    /**
     * NotNull and Size annotations validate the entered data
     */
    @NotNull(message = "Text can not be null")
    @Size(min=5, message = "min 5 characters")
    public String text;

    public String data;

    /**
     * NotNull and Size annotations validate the entered data
     */
    @NotNull(message = "News can not be null")
    @Size(max=500, message = "max 500 characters")
    public News () {}

    /**
     * Constructor
     * @param title
     * @param text
     * @param data
     */
    public News(String title, String text, String data) {
        this.title = title;
        this.text = text;
        this.data = data;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
