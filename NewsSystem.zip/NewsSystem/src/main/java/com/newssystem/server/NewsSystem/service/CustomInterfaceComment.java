package com.newssystem.server.NewsSystem.service;

import com.newssystem.server.NewsSystem.domain.Comment;

import java.util.List;

/**
 * An interface containing methods not related to News and Comment
 */

public interface CustomInterfaceComment {

    /**
     * Returns a list of comments by NewsId
     * @param id - news id
     * @return - comment list
     */
    List<Comment> findByNewsId(String id);
}
