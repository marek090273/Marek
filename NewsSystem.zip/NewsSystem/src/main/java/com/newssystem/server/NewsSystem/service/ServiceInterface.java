package com.newssystem.server.NewsSystem.service;

import java.util.List;

/**
 *
 * Interface for services enabling operations on the database
 * @param <T> - A generic type that allows to create methods for both services Comment and News. Can be replaced with class News or Comment
 */

public interface ServiceInterface<T> {

    /**
     * List of all objects in a given class
     * @return
     */
    List<T> getObj();

    /**
     * Creating a new entry in the database
     * @param obj
     * @return
     */
    T create(T obj);

    /**
     * Searching for the record using the identifier
     * @param id
     * @return
     */
    T findById(String id);

    /**
     * Update the record in the database
     * @param obj
     * @return
     */
    T update(T obj);

}
