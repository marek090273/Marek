package com.newssystem.server.NewsSystem;

import com.newssystem.server.NewsSystem.domain.Comment;
import com.newssystem.server.NewsSystem.domain.News;
import com.newssystem.server.NewsSystem.service.CommentService;
import com.newssystem.server.NewsSystem.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


/**
 * Main class of the application
 * Implements CommandLineRunner interface that allows add some information to database
 * Annotation @SpringBootApplication indicates that Spring will start running the application from this place.
 */


@SpringBootApplication
@Configuration
@ComponentScan
public class NewsSystemApplication implements CommandLineRunner {

	@Autowired
	public NewsService newsService;

	@Autowired
	public CommentService commentService;

	public static void main(String[] args) {
		SpringApplication.run(NewsSystemApplication.class, args);
	}

	/**
	 * Method run starts when Spring finishes starting all its components and applications
	 * @param args
	 * @throws Exception
	 */
	@Override
	public void run(String... args) throws Exception {

		News obj = new News("30.08.2018", "Title", "Text");

		newsService.create(obj);

		Comment commObj = new Comment("13456245", "Text", "Author", "30.08.2018");

		commentService.create(commObj);

	}
}
